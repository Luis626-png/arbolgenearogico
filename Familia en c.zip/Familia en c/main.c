#include <stdio.h>
#include <stdlib.h>

int main() {
	int op;
	printf("\nBernal Guillen Luis Angel\n");
	printf("\nArbol Genealogico\n");
	printf("\n1. Familiares de Generacion 1\n");
	printf("\n2. Familiares de Generacion 2\n");
	printf("\n3. Familiares de Generacion 3\n");
	printf("\n4. Familiares de Generacion 4\n");
	printf("\n5. Familiares de Generacion 5\n");
	printf("\n6. Familiares de Generacion 6\n");
	
	scanf("%d,&op");
	switch(op)
	{
		case 1:
			printf("\nFamiliares de Generacion 1");
			printf("Abulos Maternos");
			printf("Marta Guillen");
			printf("Luz de la Paz Guillen");
			printf("Sulma Guillen");
			printf("Trinidad Guillen");
			printf("Fernanda Guillen ");
			printf("Beatriz Guillen");
			printf("Anastacia Guillen");
			break;
		case 2:
			printf("\nFamiliares de Generacion 2");
            printf("Abuelos Paterno");
            printf("Severo Bernal");
            printf("Lasaro Bernal");
            printf("Andres Bernal");
            printf("Juan Bernal");
            printf("Lupe Bernal");
            printf("Egracia Bernal");
			break;
	    case  3 :
            printf ("Familiares de Generacion 3\n");
            printf("Mi Jefe y hermanos");
            printf("Jose Luis Bernal");
            printf("Javier Bernal");
            printf("Jacobo Bernal");
            printf("Severo Bernal");
            
            printf("Mi Jefa y hermanas");
            printf("Rita Guillen");
            printf("Francisco Guillen");
            printf("Aurora Guillen");
            printf("Maria Guillen");
            break ;
        case  4 :
            printf ("Familiares de Generacion 4\n");
            printf("Primos de toda mi familia");
            printf("Cristian Bernal");
            printf("Diego Guillen");
            printf("Brayan Bernal");
            printf("Brandon Bernal");
            printf("Alana Guillen");
            printf("Elooy Bernal");
            printf("Carmen Bernal");
            printf("Mago Bernal");
            break ;
        case  5 :
            printf ("Familiares de Generacion 5 \n");
            printf("Mis sobrinas");
            printf("Alexia Guillen");
            printf("Fernanda Guillen");
            printf("Andrea Guillen");
            printf("Daniel Guillen");
            break ;
        case  6 :
            printf ("Familiares de Generacion 6 \n");
            printf("Mi Familia fuera ");
            printf("Beatriz Hernandez");
            printf("Claudia isabel");
	}
	return 0;
}
